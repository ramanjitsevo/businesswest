<?php
/**
 * Uncode Menu Toggle config
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

vc_map(array(
	'name' => esc_html__('Toggle', 'uncode-core') ,
	'base' => 'uncode_menu_toggle',
	'weight' => 9100,
	// 'icon' => 'fa fa-close',
	'icon' => 'fa fa-cross',
	'wrapper_class' => 'clearfix',
	'description' => esc_html__('Menu toggle close', 'uncode-core') ,
	'params' => array(
		array(
			'type' => 'uncode_shortcode_id',
			'heading' => esc_html__('Unique ID', 'uncode-core') ,
			'param_name' => 'uncode_shortcode_id',
			'description' => '',
		) ,
		array(
			'type' => 'dropdown',
			'heading' => esc_html__( 'Position', 'uncode-core') ,
			'param_name' => 'position',
			'admin_label' => true,
			'value' => array(
				esc_html__('Absolute', 'uncode-core') => '',
				esc_html__('Relative', 'uncode-core') => 'relative',
			) ,
			'description' => esc_html__('Set a position method.', 'uncode-core'),
		),
		array(
			'type' => 'textfield',
			'heading' => esc_html__('Top position', 'uncode-core') ,
			'description' => esc_html__('Define the top position.', 'uncode-core'),
			'param_name' => 'top_position',
			'dependency' => array(
				'element' => 'position',
				'is_empty' => true,
			) ,
		),
		array(
			'type' => 'textfield',
			'heading' => esc_html__('Right position', 'uncode-core') ,
			'description' => esc_html__('Define the right position.', 'uncode-core'),
			'param_name' => 'right_position',
			'dependency' => array(
				'element' => 'position',
				'is_empty' => true,
			) ,
		),
		array(
			'type' => 'textfield',
			'heading' => esc_html__('Bottom position', 'uncode-core') ,
			'description' => esc_html__('Define the bottom position.', 'uncode-core'),
			'param_name' => 'bottom_position',
			'dependency' => array(
				'element' => 'position',
				'is_empty' => true,
			) ,
		),
		array(
			'type' => 'textfield',
			'heading' => esc_html__('Left position', 'uncode-core') ,
			'description' => esc_html__('Define the left position.', 'uncode-core'),
			'param_name' => 'left_position',
			'dependency' => array(
				'element' => 'position',
				'is_empty' => true,
			) ,
		),
		array(
			'type' => 'textfield',
			'heading' => esc_html__('Z-Index', 'uncode-core') ,
			'description' => esc_html__('Set a custom z-index.', 'uncode-core'),
			'param_name' => 'z_index',
			'dependency' => array(
				'element' => 'position',
				'is_empty' => true,
			) ,
		),
		array(
			'type' => 'textfield',
			'heading' => esc_html__('Extra class name', 'uncode-core') ,
			'param_name' => 'el_class',
			'description' => esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your CSS file.', 'uncode-core'),
			"group" => esc_html__("Extra", 'uncode-core') ,
		),
    )
));
