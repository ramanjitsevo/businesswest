<?php
/**
 * Menu Block config
 */

 if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$custom_menus = [];
$custom_menus[esc_html__('None', 'uncode-core')] = '';
$custom_menus[esc_html__('Inherit', 'uncode-core')] = 'inherit';
$custom_menus_slug = [];
$custom_menus_slug[esc_html__('None', 'uncode-core')] = '';
$custom_menus_slug[esc_html__('Inherit', 'uncode-core')] = 'inherit';
// phpcs:ignore
$menus = get_terms( 'nav_menu', array( 'hide_empty' => false ) );
if ( is_array( $menus ) && ! empty( $menus ) ) {
	foreach ( $menus as $single_menu ) {
		if ( is_object( $single_menu ) && isset( $single_menu->name, $single_menu->term_id ) ) {
			$custom_menus[ $single_menu->name ] = $single_menu->term_id;
		}
		if ( is_object( $single_menu ) && isset( $single_menu->name, $single_menu->slug ) ) {
			$custom_menus_slug[ $single_menu->name ] = array($single_menu->slug, $single_menu->term_id);
		}
	}
}

$items_color_options = uncode_core_vc_params_get_advanced_color_options( 'items_color', esc_html__("Color", 'uncode-core'), esc_html__("Specify the color.", 'uncode-core'), esc_html__("Items", 'uncode-core'), $uncode_colors, array( 'flat' => true ) );
list( $add_items_color_type, $add_items_color, $add_items_color_solid ) = $items_color_options;
$items_hover_color_options = uncode_core_vc_params_get_advanced_color_options( 'items_hover_color', esc_html__("Hover", 'uncode-core'), esc_html__("Specify the hover color.", 'uncode-core'), esc_html__("Items", 'uncode-core'), $uncode_colors, array( 'flat' => true ) );
list( $add_items_hover_color_type, $add_items_hover_color, $add_items_hover_color_solid ) = $items_hover_color_options;
$items_active_color_options = uncode_core_vc_params_get_advanced_color_options( 'items_active_color', esc_html__("Active", 'uncode-core'), esc_html__("Specify the active color.", 'uncode-core'), esc_html__("Items", 'uncode-core'), $uncode_colors, array( 'flat' => true ) );
list( $add_items_active_color_type, $add_items_active_color, $add_items_active_color_solid ) = $items_active_color_options;

$titles_color_options = uncode_core_vc_params_get_advanced_color_options( 'titles_color', esc_html__("Color", 'uncode-core'), esc_html__("Specify the color.", 'uncode-core'), esc_html__("Parents", 'uncode-core'), $uncode_colors, array( 'flat' => true ) );
list( $add_titles_color_type, $add_titles_color, $add_titles_color_solid ) = $titles_color_options;
$titles_hover_color_options = uncode_core_vc_params_get_advanced_color_options( 'titles_hover_color', esc_html__("Hover", 'uncode-core'), esc_html__("Specify the hover color.", 'uncode-core'), esc_html__("Parents", 'uncode-core'), $uncode_colors, array( 'flat' => true ) );
list( $add_titles_hover_color_type, $add_titles_hover_color, $add_titles_hover_color_solid ) = $titles_hover_color_options;
$titles_active_color_options = uncode_core_vc_params_get_advanced_color_options( 'titles_active_color', esc_html__("Active", 'uncode-core'), esc_html__("Specify the active color.", 'uncode-core'), esc_html__("Parents", 'uncode-core'), $uncode_colors, array( 'flat' => true ) );
list( $add_titles_active_color_type, $add_titles_active_color, $add_titles_active_color_solid ) = $titles_active_color_options;

$descriptions_color_options = uncode_core_vc_params_get_advanced_color_options( 'descriptions_color', esc_html__("Descriptions Color", 'uncode-core'), esc_html__("Specify the color.", 'uncode-core'), esc_html__("Descriptions", 'uncode-core'), $uncode_colors, array( 'flat' => true ) );
list( $add_descriptions_color_type, $add_descriptions_color, $add_descriptions_color_solid ) = $descriptions_color_options;

$icon_color_options = uncode_core_vc_params_get_advanced_color_options( 'icon_color', esc_html__("Icon Color", 'uncode-core'), esc_html__("Specify icon color. The background is automatically colored unless specified. NB. This doesn't work for media icons.", 'uncode-core'), esc_html__("Media & Icon", 'uncode-core'), $uncode_colors );
list( $add_icon_color_type, $add_icon_color, $add_icon_color_solid, $add_icon_color_gradient ) = $icon_color_options;
$icon_bg_color_options = uncode_core_vc_params_get_advanced_color_options( 'icon_bg_color', esc_html__("Background Color", 'uncode-core'), esc_html__("Specify media background color.", 'uncode-core'), esc_html__("Media & Icon", 'uncode-core'), $uncode_colors, array( 'dependency' => array( 'element' => 'background_style', 'not_empty' => true ) ) );
list( $add_icon_bg_color_type, $add_icon_bg_color, $add_icon_bg_color_solid, $add_icon_bg_color_gradient ) = $icon_bg_color_options;

$icon_accordion_color_options = uncode_core_vc_params_get_advanced_color_options( 'icon_accordion_color', esc_html__("Icon Color", 'uncode-core'), esc_html__("Specify icon color.", 'uncode-core'), esc_html__("Collapsible", 'uncode-core'), $uncode_colors, array( 'flat' => true, 'dependency' => array( 'element' => 'accordion_icon', 'not_empty' => true, ) )  );
list( $add_icon_accordion_color_type, $add_icon_accordion_color, $add_icon_accordion_color_solid ) = $icon_accordion_color_options;

$uncode_menu_font = $heading_font;
unset( $uncode_menu_font[esc_html__('Default', 'uncode-core')] );
$uncode_menu_font_inherit = array(
	esc_html__('Inherit', 'uncode-core') => '',
);
$uncode_menu_font = $uncode_menu_font_inherit + $uncode_menu_font;

$menu_params = array(
	array(
		'type' => 'uncode_shortcode_id',
		'heading' => esc_html__('Unique ID', 'uncode-core') ,
		'param_name' => 'uncode_shortcode_id',
		'description' => '',
		"group" => esc_html__("General", 'uncode-core') ,
	) ,
	array(
		'type' => 'dropdown',
		'heading' => esc_html__( 'Menu', 'uncode-core') ,
		'param_name' => 'nav_menu',
		'value' => $custom_menus,
		'description' => empty( $custom_menus ) ? sprintf( esc_html__( 'Custom menus not found. Please visit %1$sAppearance > Menus%2$s page to create new menu.', 'uncode-core' ), '<b>', '</b>' ) : esc_html__( 'Select menu to display.', 'uncode-core' ),
		"group" => esc_html__("General", 'uncode-core') ,
		'dependency' => array(
			'element' => 'slug',
			'is_empty' => true,
		) ,
		'admin_label' => true,
	),
	array(
		'type' => 'uncode_select_data_attr',
		'heading' => esc_html__( 'Menu', 'uncode-core') ,
		'param_name' => 'nav_menu_slug',
		'data' => 'id',
		'value' => $custom_menus_slug,
		'description' => empty( $custom_menus_slug ) ? sprintf( esc_html__( 'Custom menus not found. Please visit %1$sAppearance > Menus%2$s page to create new menu.', 'uncode-core' ), '<b>', '</b>' ) : esc_html__( 'Connect any WordPress Menu to the module. NB. Note that Menus cannot exceed three levels (Parent → Child → Child). Additionally, Menus containing Content Blocks are not accepted within the Menu Block to prevent recursive nested Content Block loops, which could potentially create infinite Menu structures within infinite Content Blocks.', 'uncode-core' ),
		"group" => esc_html__("General", 'uncode-core') ,
		'dependency' => array(
			'element' => 'slug',
			'not_empty' => true,
		) ,
		'admin_label' => true,
	),
	array(
		'type' => 'textfield',
		'heading' => esc_html__('Columns', 'uncode-core') ,
		'param_name' => 'menu_layout',
		'description' => esc_html__('Configure the number of Columns for Menu display. Values can be responsive across three breakpoints (desktop, tablet, mobile) by entering for example "4,3,1". NB. These utilize CSS Grid layouts flowing left to right, not vertical stacking, before moving to new Columns.', 'uncode-core') ,
		"group" => esc_html__("General", 'uncode-core') ,
	) ,
	array(
		"type" => "type_numeric_slider",
		'heading' => esc_html__('Columns Gap', 'uncode-core') ,
		"param_name" => "gutter_size",
		"min" => 0,
		"max" => 4,
		"step" => 1,
		"value" => 3,
		'dependency' => array(
			'element' => 'menu_layout',
			'not_empty' => true,
		) ,
		'description' => esc_html__('Sets horizontal spacing between Columns according to Uncode\'s grid spacing values, enabling alignment with other grid elements.', 'uncode-core') ,
		"group" => esc_html__("General", 'uncode-core') ,
	) ,
	array(
		"type" => 'checkbox',
		"heading" => esc_html__("Columns First Level", 'uncode-core') ,
		"param_name" => "columns_first",
		"description" => esc_html__("Determines whether Columns apply to the deepest Menu level, or to the top-level items. With this option enabled, the Columns are applied to the Titles level.", 'uncode-core') ,
		"value" => Array(
			'' => 'yes'
		) ,
		'dependency' => array(
			'element' => 'menu_layout',
			'not_empty' => true,
		) ,
		"group" => esc_html__("General", 'uncode-core')
	) ,
	array(
		"type" => 'dropdown',
		"heading" => esc_html__("Collapsible", 'uncode-core') ,
		"param_name" => "title_accordion",
		"description" => esc_html__("Transforms horizontal Menus into vertical accordions, either on desktop for creating expandable Menu sections or mobile-only behavior. NB. It works only with multilevel.", 'uncode-core') ,
		"value" => array(
			esc_html__('No', 'uncode-core') => '',
			esc_html__('Always', 'uncode-core') => 'yes',
			esc_html__('Mobile', 'uncode-core') => 'mobile',
		) ,
		'std' => '',
		"group" => esc_html__("Collapsible", 'uncode-core'),
	) ,
	array(
		'type' => 'iconpicker',
		'heading' => esc_html__('Icon', 'uncode-core') ,
		'param_name' => 'accordion_icon',
		'description' => esc_html__('Specify icon from library.', 'uncode-core') ,
		'value' => '',
		'settings' => array(
			'emptyIcon' => true,
			'iconsPerPage' => 1100,
			'type' => 'uncode'
		) ,
		'dependency' => array(
			'element' => 'title_accordion',
			'not_empty' => true,
		) ,
		"group" => esc_html__("Collapsible", 'uncode-core'),
	) ,
	array(
		'type' => 'iconpicker',
		'heading' => esc_html__('Icon Close', 'uncode-core') ,
		'param_name' => 'accordion_icon_close',
		'description' => esc_html__('Specify icon from library.', 'uncode-core') ,
		'value' => '',
		'settings' => array(
			'emptyIcon' => true,
			'iconsPerPage' => 1100,
			'type' => 'uncode'
		) ,
		'dependency' => array(
			'element' => 'accordion_icon',
			'not_empty' => true,
		) ,
		"group" => esc_html__("Collapsible", 'uncode-core'),
	) ,
	$add_icon_accordion_color_type,
	$add_icon_accordion_color,
	$add_icon_accordion_color_solid,
	array(
		'type' => 'textfield',
		'heading' => esc_html__('Icon size', 'uncode-core') ,
		'param_name' => 'icon_accordion_size',
		'description' => esc_html__('Specify the icon size.', 'uncode-core') ,
		"group" => esc_html__("Collapsible", 'uncode-core'),
		'dependency' => array(
			'element' => 'accordion_icon',
			'not_empty' => true,
		) ,
	) ,
	array(
		'type' => 'textfield',
		'heading' => esc_html__('Icon min-width', 'uncode-core') ,
		'param_name' => 'icon_accordion_min_width',
		'description' => esc_html__('Specify the icon min-width.', 'uncode-core') ,
		"group" => esc_html__("Collapsible", 'uncode-core'),
		'dependency' => array(
			'element' => 'accordion_icon',
			'not_empty' => true,
		) ,
	) ,
	array(
		"type" => 'dropdown',
		"heading" => esc_html__("Font family", 'uncode-core') ,
		"param_name" => "text_font",
		"description" => esc_html__("Specify heading font family.", 'uncode-core') ,
		"value" => $uncode_menu_font,
		'std' => '',
		"group" => esc_html__("Items", 'uncode-core') ,
	) ,
	$add_items_color_type,
	$add_items_color,
	$add_items_color_solid,
	$add_items_hover_color_type,
	$add_items_hover_color,
	$add_items_hover_color_solid,
	$add_items_active_color_type,
	$add_items_active_color,
	$add_items_active_color_solid,
	array(
		"type" => 'dropdown',
		"heading" => esc_html__("Font size", 'uncode-core') ,
		"param_name" => "text_size",
		"description" => esc_html__("Specify a font size.", 'uncode-core') ,
		'std' => '',
		"value" => array(
			esc_html__('Inherit', 'uncode-core') => '',
			esc_html__('Custom', 'uncode-core') => 'custom',
		) ,
		'group' => esc_html__('Items', 'uncode-core')
	) ,
	array(
		'type' => 'textfield',
		'heading' => esc_html__('Custom font size', 'uncode-core') ,
		'param_name' => 'heading_custom_size',
		'description' => esc_html__('Specify a custom font size, ex: clamp(30px,5vw,75px), 4em, etc.', 'uncode-core') ,
		'group' => esc_html__('Items', 'uncode-core'),
		'dependency' => array(
			'element' => 'text_size',
			'value' => array('custom'),
		) ,
	) ,
	array(
		"type" => 'dropdown',
		"heading" => esc_html__("Font weight", 'uncode-core') ,
		"param_name" => "text_weight",
		"description" => esc_html__("Specify font weight.", 'uncode-core') ,
		"value" => $heading_weight,
		'std' => '',
		'group' => esc_html__('Items', 'uncode-core')
	) ,
	array(
		"type" => 'dropdown',
		"heading" => esc_html__("Text transform", 'uncode-core') ,
		"param_name" => "text_transform",
		"description" => esc_html__("Specify the text transformation.", 'uncode-core') ,
		"value" => array(
			esc_html__('Default', 'uncode-core') => '',
			esc_html__('Uppercase', 'uncode-core') => 'uppercase',
			esc_html__('Lowercase', 'uncode-core') => 'lowercase',
			esc_html__('Capitalize', 'uncode-core') => 'capitalize'
		) ,
		"group" => esc_html__("Items", 'uncode-core')
	) ,
	array(
		"type" => 'dropdown',
		"heading" => esc_html__("Line height", 'uncode-core') ,
		"param_name" => "text_height",
		"description" => esc_html__("Specify the line height.", 'uncode-core') ,
		"value" => $heading_height,
		'group' => esc_html__('Items', 'uncode-core')
	) ,
	array(
		"type" => 'dropdown',
		"heading" => esc_html__("Letter spacing", 'uncode-core') ,
		"param_name" => "text_space",
		"description" => esc_html__("Specify the letter spacing.", 'uncode-core') ,
		"value" => $heading_space,
		'group' => esc_html__('Items', 'uncode-core')
	) ,		
	array(
		"type" => 'dropdown',
		"heading" => esc_html__("Italic", 'uncode-core') ,
		"param_name" => "text_italic",
		"description" => esc_html__("Transform the text to italic.", 'uncode-core') ,
		"value" => array(
			esc_html__('Normal', 'uncode-core') => '',
			esc_html__('Italic', 'uncode-core') => 'yes',
		) ,
		"group" => esc_html__("Items", 'uncode-core')
	) ,
	array(
		"type" => 'checkbox',
		"heading" => esc_html__("No Link Title", 'uncode-core') ,
		"param_name" => "no_link",
		"description" => esc_html__("Removes links from title elements. NB. Only visible when Menu is not collapsible, as collapsible Menus automatically remove links since clicks are reserved for Menu expansion.", 'uncode-core') ,
		"value" => Array(
			'' => 'yes'
		) ,
		"group" => esc_html__("Parents", 'uncode-core') ,
		'dependency' => array(
			'element' => 'title_accordion',
			'is_empty' => true,
		) ,
	) ,
	array(
		"type" => 'dropdown',
		"heading" => esc_html__("Font family", 'uncode-core') ,
		"param_name" => "title_font",
		"description" => esc_html__("Specify heading font family.", 'uncode-core') ,
		"value" => $uncode_menu_font,
		'std' => '',
		"group" => esc_html__("Parents", 'uncode-core') ,
	) ,	
	$add_titles_color_type,
	$add_titles_color,
	$add_titles_color_solid,
	$add_titles_hover_color_type,
	$add_titles_hover_color,
	$add_titles_hover_color_solid,
	$add_titles_active_color_type,
	$add_titles_active_color,
	$add_titles_active_color_solid,
	array(
		"type" => 'dropdown',
		"heading" => esc_html__("Semantic", 'uncode-core') ,
		"param_name" => "title_semantic",
		"description" => esc_html__("Specify element tag.", 'uncode-core') ,
		"value" => $heading_semantic,
		'std' => 'div',
		"group" => esc_html__("Parents", 'uncode-core') ,
	) ,
	array(
		"type" => 'dropdown',
		"heading" => esc_html__("Font size", 'uncode-core') ,
		"param_name" => "title_size",
		"description" => esc_html__("Specify a font size.", 'uncode-core') ,
		'std' => '',
		"value" => array(
			esc_html__('Inherit', 'uncode-core') => '',
			esc_html__('Custom', 'uncode-core') => 'custom',
		) ,
		"group" => esc_html__("Parents", 'uncode-core') ,
	) ,
	array(
		'type' => 'textfield',
		'heading' => esc_html__('Custom font size', 'uncode-core') ,
		'param_name' => 'title_custom_size',
		'description' => esc_html__('Specify a custom font size, ex: clamp(30px,5vw,75px), 4em, etc.', 'uncode-core') ,
		"group" => esc_html__("Parents", 'uncode-core') ,
		'dependency' => array(
			'element' => 'title_size',
			'value' => array('custom'),
		) ,
	) ,
	array(
		"type" => 'dropdown',
		"heading" => esc_html__("Font Size Nested", 'uncode-core') ,
		"param_name" => "sec_size",
		"description" => esc_html__("Specify a font size.", 'uncode-core') ,
		'std' => '',
		"value" => array(
			esc_html__('Inherit', 'uncode-core') => '',
			esc_html__('Custom', 'uncode-core') => 'custom',
		) ,
		"group" => esc_html__("Parents", 'uncode-core') ,
	) ,
	array(
		'type' => 'textfield',
		'heading' => esc_html__('Nested Custom Font Size', 'uncode-core') ,
		'param_name' => 'sec_custom_size',
		'description' => esc_html__('Specify a custom font size, ex: clamp(30px,5vw,75px), 4em, etc.', 'uncode-core') ,
		"group" => esc_html__("Parents", 'uncode-core') ,
		'dependency' => array(
			'element' => 'sec_size',
			'value' => array('custom'),
		) ,
	) ,
	array(
		"type" => 'dropdown',
		"heading" => esc_html__("Font weight", 'uncode-core') ,
		"param_name" => "title_weight",
		"description" => esc_html__("Specify font weight.", 'uncode-core') ,
		"value" => $heading_weight,
		'std' => '',
		"group" => esc_html__("Parents", 'uncode-core') ,
	) ,
	array(
		"type" => 'dropdown',
		"heading" => esc_html__("Text transform", 'uncode-core') ,
		"param_name" => "title_transform",
		"description" => esc_html__("Specify the text transformation.", 'uncode-core') ,
		"value" => array(
			esc_html__('Default', 'uncode-core') => '',
			esc_html__('Uppercase', 'uncode-core') => 'uppercase',
			esc_html__('Lowercase', 'uncode-core') => 'lowercase',
			esc_html__('Capitalize', 'uncode-core') => 'capitalize'
		) ,
		"group" => esc_html__("Parents", 'uncode-core'),
	) ,
	array(
		"type" => 'dropdown',
		"heading" => esc_html__("Line height", 'uncode-core') ,
		"param_name" => "title_height",
		"description" => esc_html__("Specify the line height.", 'uncode-core') ,
		"value" => $heading_height,
		"group" => esc_html__("Parents", 'uncode-core') ,
	) ,
	array(
		"type" => 'dropdown',
		"heading" => esc_html__("Letter spacing", 'uncode-core') ,
		"param_name" => "title_space",
		"description" => esc_html__("Specify the letter spacing.", 'uncode-core') ,
		"value" => $heading_space,
		"group" => esc_html__("Parents", 'uncode-core') ,
	) ,		
	array(
		"type" => 'dropdown',
		"heading" => esc_html__("Italic", 'uncode-core') ,
		"param_name" => "title_italic",
		"description" => esc_html__("Transform the text to italic.", 'uncode-core') ,
		"value" => array(
			esc_html__('Normal', 'uncode-core') => '',
			esc_html__('Italic', 'uncode-core') => 'yes',
		) ,
		"group" => esc_html__("Parents", 'uncode-core'),
	) ,
	array(
		'type' => 'textfield',
		'heading' => esc_html__('Items (all)', 'uncode-core') ,
		'param_name' => 'menu_gap',
		'description' => esc_html__('Set the vertical spacing rhythm between all elements in a Menu list. Default value is 9px.', 'uncode-core') ,
		"group" => esc_html__("Spacing", 'uncode-core') ,
	) ,
	array(
		'type' => 'textfield',
		'heading' => esc_html__('First parents', 'uncode-core') ,
		'param_name' => 'titles_top',
		'description' => esc_html__('Define the top margin applied to first-level Parent elements relative to any preceding element.', 'uncode-core') ,
		"group" => esc_html__("Spacing", 'uncode-core'),
	) ,
	array(
		'type' => 'textfield',
		'heading' => esc_html__('Nested parents', 'uncode-core') ,
		'param_name' => 'nested_top',
		'description' => esc_html__('If a second level of nested Parent elements exists beyond the first level, this defines the top margin applied to these nested Parent elements relative to any preceding element.', 'uncode-core') ,
		"group" => esc_html__("Spacing", 'uncode-core') ,
	) ,
	array(
		'type' => 'textfield',
		'heading' => esc_html__('Items lists gap', 'uncode-core') ,
		'param_name' => 'titles_gap',
		'description' => esc_html__('Set the top margin applied to Menu items relative to their Parent element.', 'uncode-core') ,
		"group" => esc_html__("Spacing", 'uncode-core')
	) ,
	array(
		'type' => 'textfield',
		'heading' => esc_html__('Nested  lists gap', 'uncode-core') ,
		'param_name' => 'nested_list_gap',
		'description' => esc_html__('If a second level of nested elements exists, this defines the top margin applied to nested items relative to their Parent element.', 'uncode-core') ,
		"group" => esc_html__("Spacing", 'uncode-core'),
	) ,
	array(
		'type' => 'textfield',
		'heading' => esc_html__('Indentation', 'uncode-core') ,
		'param_name' => 'indent',
		'description' => esc_html__('Available only for Collapsible Menus, this option defines the indentation rhythm between different list levels. Useful for establishing visual hierarchy in Vertical and Mobile Menus.', 'uncode-core') ,
		'dependency' => array(
			'element' => 'title_accordion',
			'not_empty' => true,
		) ,
		"group" => esc_html__("Spacing", 'uncode-core'),
	) ,
	array(
		"type" => 'checkbox',
		"heading" => esc_html__("Hide Media & Icons", 'uncode-core') ,
		"param_name" => "icon",
		"description" => esc_html__("Hide possible Media and Icons set from the Menu Editor.", 'uncode-core') ,
		"value" => Array(
			'' => 'yes'
		) ,
		"group" => esc_html__("Media & Icon", 'uncode-core'),
	) ,
	array(
		"type" => 'dropdown',
		"heading" => esc_html__("Replace", 'uncode-core') ,
		"param_name" => "icon_replace",
		"description" => esc_html__("Apply Icons or Media to all Menu elements. Useful for adding decorative elements like arrows or consistent visual indicators to all items.", 'uncode-core') ,
		"value" => array(
			esc_html__('No', 'uncode-core') => '',
			esc_html__('Icon', 'uncode-core') => 'icon',
			esc_html__('Media', 'uncode-core') => 'media',
		) ,
		"group" => esc_html__("Media & Icon", 'uncode-core'),
	) ,
	array(
		'type' => 'iconpicker',
		'heading' => esc_html__('Icon', 'uncode-core') ,
		'param_name' => 'icon_alt',
		'description' => esc_html__('Specify icon from library.', 'uncode-core') ,
		'value' => '',
		'settings' => array(
			'emptyIcon' => true,
			'iconsPerPage' => 1100,
			'type' => 'uncode'
		) ,
		'dependency' => array(
			'element' => 'icon_replace',
			'value' => array('icon'),
		) ,
		"group" => esc_html__("Media & Icon", 'uncode-core'),
	) ,
	array(
		"type" => "media_element",
		"heading" => esc_html__("Media", 'uncode-core') ,
		"param_name" => "media",
		"value" => "",
		"edit_field_class" => 'vc_column uncode_single_media',
		"description" => esc_html__("Specify a media from the Media Library.", 'uncode-core') ,
		'dependency' => array(
			'element' => 'icon_replace',
			'value' => array('media'),
		) ,
		"group" => esc_html__("Media & Icon", 'uncode-core'),
	) ,
	array(
		"type" => 'dropdown',
		"heading" => esc_html__("Media align", 'uncode-core') ,
		"param_name" => "icon_align",
		"description" => esc_html__("Set the media alignment.", 'uncode-core') ,
		"value" => array(
			esc_html__('Top', 'uncode-core') => '',
			esc_html__('Middle', 'uncode-core') => 'middle',
		) ,
		"group" => esc_html__("Media & Icon", 'uncode-core'),
	) ,
	array(
		"type" => 'checkbox',
		'heading' => esc_html__( 'Reduce Space', 'uncode-core') ,
		'param_name' => 'icon_space_reduce',
		"description" => esc_html__("Reduce the space between the item and the media or icon.", 'uncode-core') ,
		"value" => Array(
			'' => 'yes'
		) ,
		"group" => esc_html__("Media & Icon", 'uncode-core'),
	),
	$add_icon_color_type,
	$add_icon_color,
	$add_icon_color_solid,
	$add_icon_color_gradient,
	array(
		'type' => 'textfield',
		'heading' => esc_html__('Icon Size', 'uncode-core') ,
		'param_name' => 'font_icon_size',
		'description' => esc_html__('Specify a custom font size for the icon, ex: clamp(30px,5vw,75px), 4em, etc. NB. Icon Size applies to both icons and media as the primary value, while Media Size applies exclusively to media elements.', 'uncode-core') ,
		"group" => esc_html__("Media & Icon", 'uncode-core'),
	) ,
	array(
		'type' => 'textfield',
		'heading' => esc_html__('Media Size', 'uncode-core') ,
		'param_name' => 'media_icon_size',
		'description' => esc_html__('Specify a custom media width, ex: clamp(30px,5vw,75px), 4em, etc.', 'uncode-core') ,
		"group" => esc_html__("Media & Icon", 'uncode-core'),
	) ,
	array(
		'type' => 'dropdown',
		'heading' => esc_html__('Background', 'uncode-core') ,
		'param_name' => 'background_style',
		'value' => array(
			esc_html__('None', 'uncode-core') => '',
			esc_html__('Rounded', 'uncode-core') => 'fa-radius',
			esc_html__('Circle', 'uncode-core') => 'fa-rounded',
			esc_html__('Square', 'uncode-core') => 'fa-squared',
		) ,
		"group" => esc_html__("Media & Icon", 'uncode-core'),
		'description' => esc_html__("Background style for media.", 'uncode-core')
	) ,
	$add_icon_bg_color_type,
	$add_icon_bg_color,
	$add_icon_bg_color_solid,
	$add_icon_bg_color_gradient,
	array(
		'type' => 'textfield',
		'heading' => esc_html__('Background Size', 'uncode-core') ,
		'param_name' => 'bg_size',
		'description' => esc_html__('Specify a custom size, ex: clamp(30px,5vw,75px), 4em, etc.', 'uncode-core') ,
		"group" => esc_html__("Media & Icon", 'uncode-core'),
		'dependency' => array(
			'element' => 'background_style',
			'not_empty' => true,
		) ,
	) ,
	array(
		"type" => 'checkbox',
		"heading" => esc_html__("Display descriptions", 'uncode-core') ,
		"param_name" => "description",
		"description" => esc_html__("Display the available descriptions added to the Menu Editor.", 'uncode-core') ,
		"value" => Array(
			'' => 'yes'
		) ,
		"group" => esc_html__("Descriptions", 'uncode-core') ,
	) ,
	array(
		'type' => 'textfield',
		'heading' => esc_html__('Description Custom Size', 'uncode-core') ,
		'param_name' => 'description_custom_size',
		'description' => esc_html__('Specify a custom font size, ex: clamp(30px,5vw,75px), 4em, etc.', 'uncode-core') ,
		"group" => esc_html__("Descriptions", 'uncode-core') ,
		'dependency' => array(
			'element' => 'description',
			'not_empty' => true,
		) ,
	) ,
	$add_descriptions_color_type,
	$add_descriptions_color,
	$add_descriptions_color_solid,
	array(
		"type" => 'checkbox',
		"heading" => esc_html__("Desktop", 'uncode-core') ,
		"param_name" => "desktop_visibility",
		"description" => esc_html__("Choose the visibiliy of the element in desktop layout mode (960px >).", 'uncode-core') ,
		'group' => esc_html__('Responsive', 'uncode-core') ,
		"value" => Array(
			'' => 'yes'
		) ,
	) ,
	array(
		"type" => 'checkbox',
		"heading" => esc_html__("Tablet", 'uncode-core') ,
		"param_name" => "medium_visibility",
		"description" => esc_html__("Choose the visibiliy of the element in tablet layout mode (570px > < 960px).", 'uncode-core') ,
		'group' => esc_html__('Responsive', 'uncode-core') ,
		"value" => Array(
			'' => 'yes'
		) ,
	) ,
	array(
		"type" => 'checkbox',
		"heading" => esc_html__("Mobile", 'uncode-core') ,
		"param_name" => "mobile_visibility",
		"description" => esc_html__("Choose the visibiliy of the element in mobile layout mode (< 570px).", 'uncode-core') ,
		'group' => esc_html__('Responsive', 'uncode-core') ,
		"value" => Array(
			'' => 'yes'
		) ,
	) ,
);

$_extra_params = array(
	array(
		"type" => 'checkbox',
		"heading" => esc_html__("Use Slug", 'uncode-core') ,
		"param_name" => "slug",
		"description" => esc_html__("When enabled, this option references the Menu in the General tab by Slug (name) instead of ID (number). NB. Demo Contents are configured using Slugs because it's the only reliable way to reference Menus correctly during Demo Import (also useful for exports). However, we recommend disabling this option and using IDs instead, as they provide a more dynamic workflow — allowing you to rename Menus freely and ensuring better compatibility with multilingual plugins.", 'uncode-core') ,
		"value" => Array(
			'' => 'yes'
		) ,
		"group" => esc_html__("Extra", 'uncode-core')
	),
);

if ( apply_filters( 'uncode_activate_menu_badges', false ) ) {
	$_extra_params[] = array(
		"type" => 'checkbox',
		"heading" => esc_html__("Display badges", 'uncode-core') ,
		"param_name" => "badge",
		"description" => esc_html__("Display the menu badges.", 'uncode-core') ,
		"value" => Array(
			'' => 'yes'
		) ,
		"group" => esc_html__("Extra", 'uncode-core')
	);
	$_extra_params[] = array(
		'type' => 'dropdown',
		"heading" => esc_html__("Badges position", 'uncode-core') ,
		"param_name" => "badge_pos",
		"description" => esc_html__("Set the badge position method.", 'uncode-core') ,
		"value" => array(
			esc_html__('Relative', 'uncode-core') => '',
			esc_html__('Absolute', 'uncode-core') => 'absolute',
		) ,
		"group" => esc_html__("Extra", 'uncode-core'),
		'dependency' => array(
			'element' => 'badge',
			'not_empty' => true,
		)
	);
}

$extra_params = array_merge( $_extra_params, array(
	array(
		'type' => 'textfield',
		'heading' => esc_html__('Extra class name', 'uncode-core') ,
		'param_name' => 'el_class',
		'description' => esc_html__('If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your CSS file.', 'uncode-core'),
		"group" => esc_html__("Extra", 'uncode-core') ,
	),
	array(
		'type' => 'textfield',
		'heading' => esc_html__('Hook ID', 'uncode-core') ,
		'param_name' => 'hook_id',
		'description' => esc_html__('This option can be used by developers as a reference parameter for the `uncode_menu_block_nav_menu_id` filter, useful for advanced customizations and modifications.', 'uncode-core'),
		"group" => esc_html__("Extra", 'uncode-core') ,
	)
));


$menu_params = array_merge($menu_params, $extra_params);

vc_map(array(
	'name' => esc_html__('Menu Block', 'uncode-core') ,
	'base' => 'uncode_menu_block',
	'weight' => 9099,
	'icon' => 'fa fa-menu',
	'description' => esc_html__('Menu megamenu mega links list', 'uncode-core') ,
	'params' => $menu_params
));
