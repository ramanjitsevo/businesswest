<?php
/**
 * Menu extend functions
 */

class Uncode_Nav_Menus_Extension {
    
    public function __construct() {
        add_action('admin_init', array($this, 'add_nav_menu_meta_boxes'));
        add_action('wp_ajax_uncode_search_nav_menus', array($this, 'wp_ajax_uncode_search_nav_menus'));
        add_action('wp_ajax_add-nav_menu-menu-item', array($this, 'uncode_ajax_add_menu_item'));
    }
    
    public function wp_ajax_uncode_search_nav_menus() {
        if (!wp_verify_nonce($_POST['nonce'], 'uncode_search_nav_menus_nonce')) {
            wp_send_json_error(esc_html__( 'Security check failed.', 'uncode-core' ));
        }
        
        if (!current_user_can('edit_theme_options')) {
            wp_send_json_error(esc_html__( 'Permission denied.', 'uncode-core' ));
        }
        
        $search_term = sanitize_text_field($_POST['search_term']);
        $current_menu_id = intval($_POST['current_menu_id']);
                
        $nav_menus = wp_get_nav_menus();
        $results = array();
                
        foreach ($nav_menus as $menu) {
            if ($menu->term_id == $current_menu_id) {
                error_log(esc_html__( 'Skipping current menu: ', 'uncode-core' ) . $menu->name);
                continue;
            }
            
            if (stripos($menu->name, $search_term) !== false) {
                error_log(esc_html__( 'Match found: ', 'uncode-core' ) . $menu->name);
                $results[] = $menu;
            } else {
                error_log(esc_html__( 'No match for: ', 'uncode-core' ) . $menu->name . esc_html__( ' with term: ', 'uncode-core' ) . $search_term);
            }
        }
        
        error_log(esc_html__( 'Search results count: ', 'uncode-core' ) . count($results));
        
        if (!empty($results)) {
            $placeholder_start = -100;
            
            ob_start();
            $i = 0;
            foreach ($results as $menu) {
                $placeholder = $placeholder_start - $i;
                ?>
                <li>
                    <label class="menu-item-title">
                        <input type="checkbox" class="menu-item-checkbox" name="menu-item[<?php echo $placeholder; ?>][menu-item-object-id]" value="<?php echo esc_attr($menu->term_id); ?>" /> 
                        <?php echo esc_html($menu->name); ?>
                        <?php if (isset($menu->count) && $menu->count > 0): ?>
                            <span class="menu-item-description"><?php  sprintf( ' (%d items)', 'uncode-core', $menu->count ); ?></span>
                        <?php endif; ?>
                    </label>
                    <input type="hidden" name="menu-item[<?php echo $placeholder; ?>][menu-item-type]" value="nav_menu" />
                    <input type="hidden" name="menu-item[<?php echo $placeholder; ?>][menu-item-object]" value="nav_menu" />
                    <input type="hidden" name="menu-item[<?php echo $placeholder; ?>][menu-item-object-id]" value="<?php echo esc_attr($menu->term_id); ?>" />
                    <input type="hidden" name="menu-item[<?php echo $placeholder; ?>][menu-item-title]" value="<?php echo esc_attr($menu->name); ?>" />
                </li>
                <?php
                $i++;
            }
            $html = ob_get_clean();
            
            error_log(esc_html__( 'Generated HTML length', 'uncode-core' ) . ' :' . strlen($html));
            wp_send_json_success($html);
        } else {
            wp_send_json_error(esc_html__( 'No menus found matching ', 'uncode-core' ) . '"' . $search_term . '"');
        }
    }
    
    public function add_nav_menu_meta_boxes() {
        add_meta_box(
            'add-nav-menus',
            __('Menus', 'uncode-core'),
            array($this, 'wp_nav_menu_item_nav_menus_meta_box'),
            'nav-menus',
            'side',
            'default'
        );
    }
    
    public function wp_nav_menu_item_nav_menus_meta_box() {
        global $_nav_menu_placeholder, $nav_menu_selected_id;
        
        $_nav_menu_placeholder = 0 > $_nav_menu_placeholder ? $_nav_menu_placeholder - 1 : -1;
        
        $nav_menus = wp_get_nav_menus();
        $current_menu_id = $nav_menu_selected_id;
        
        $available_menus = array_filter($nav_menus, function($menu) use ($current_menu_id) {
            return $menu->term_id != $current_menu_id;
        });
        
        ?>
        <div id="nav_menu" class="posttypediv menu-settings-column" data-type="nav_menu" data-object="nav_menu">
            <div id="nav-menus-adder" class="wp-hidden-children">
                <div id="nav-menus-most-recent" class="tabs-panel tabs-panel-active" role="region" aria-label="Most Recent Menus" tabindex="0">
                    <ul id="nav-menus-most-recent-list" class="categorychecklist form-no-clear">
                        <?php
                        $most_recent_menus = array_slice($available_menus, 0, 15);
                        $i = -1;
                        foreach ($most_recent_menus as $menu) :
                        ?>
                            <li>
                                <label class="menu-item-title">
                                    <input type="checkbox" class="menu-item-checkbox" name="menu-item[<?php echo $_nav_menu_placeholder; ?>][menu-item-object-id]" value="<?php echo esc_attr($menu->term_id); ?>" /> 
                                    <?php echo esc_html($menu->name); ?>
                                </label>
                                <input type="hidden" class="menu-item-type" name="menu-item[<?php echo $_nav_menu_placeholder; ?>][menu-item-type]" value="nav_menu" />
                                <input type="hidden" class="menu-item-object" name="menu-item[<?php echo $_nav_menu_placeholder; ?>][menu-item-object]" value="nav_menu" />
                                <input type="hidden" class="menu-item-title" name="menu-item[<?php echo $_nav_menu_placeholder; ?>][menu-item-title]" value="<?php echo esc_attr($menu->name); ?>" />
                                <input type="hidden" class="menu-item-url" name="menu-item[<?php echo $_nav_menu_placeholder; ?>][menu-item-url]" value="" />
                                <input type="hidden" class="menu-item-classes" name="menu-item[<?php echo $_nav_menu_placeholder; ?>][menu-item-classes]" value="" />
                            </li>
                            <?php
                            $_nav_menu_placeholder = ( 0 > $_nav_menu_placeholder ) ? $_nav_menu_placeholder - 1 : -1;
                        endforeach;
                        ?>
                    </ul>
                </div>
                
                <div id="nav-menus-view-all" class="tabs-panel">
                    <ul id="nav-menus-view-all-list" class="categorychecklist form-no-clear">
                        <?php
                        $i = -1;
                        foreach ($available_menus as $menu) :
                        ?>
                            <li>
                                <label class="menu-item-title">
                                    <input type="checkbox" class="menu-item-checkbox" name="menu-item[<?php echo $_nav_menu_placeholder; ?>][menu-item-object-id]" value="<?php echo esc_attr($menu->term_id); ?>" /> 
                                    <?php echo esc_html($menu->name); ?>
                                </label>
                                <input type="hidden" class="menu-item-type" name="menu-item[<?php echo $_nav_menu_placeholder; ?>][menu-item-type]" value="nav_menu" />
                                <input type="hidden" class="menu-item-object" name="menu-item[<?php echo $_nav_menu_placeholder; ?>][menu-item-object]" value="nav_menu" />
                                <input type="hidden" class="menu-item-title" name="menu-item[<?php echo $_nav_menu_placeholder; ?>][menu-item-title]" value="<?php echo esc_attr($menu->name); ?>" />
                                <input type="hidden" class="menu-item-url" name="menu-item[<?php echo $_nav_menu_placeholder; ?>][menu-item-url]" value="" />
                                <input type="hidden" class="menu-item-classes" name="menu-item[<?php echo $_nav_menu_placeholder; ?>][menu-item-classes]" value="" />
                            </li>
                            <?php
                            $_nav_menu_placeholder = ( 0 > $_nav_menu_placeholder ) ? $_nav_menu_placeholder - 1 : -1;
                        endforeach;
                        ?>
                    </ul>
                </div>
                
                <div id="nav-menus-search" class="tabs-panel">
                    <p class="quick-search-wrap">
                        <label class="screen-reader-text" for="quick-search-nav-menus"><?php esc_attr_e( 'Search Menus', 'uncode-core' ); ?></label>
                        <input type="search" class="custom-search-input" name="custom-search-input" id="custom-search-input"/>
                        <span class="spinner"></span>
                    </p>
                    <ul id="nav-menus-search-checklist" class="categorychecklist form-no-clear">
                    </ul>
                </div>
            </div>
            
            <p class="button-controls wp-clearfix" data-add-to="nav-menus" data-type="post_type" data-object="nav_menu" data-items-type="nav_menu">
                <span class="list-controls hide-if-no-js">
                    <input type="checkbox" id="nav-menus-tab" class="select-all" />
                    <label for="nav-menus-tab"><?php esc_attr_e( 'Select All' ); ?></label>
                </span>
                
                <span class="add-to-menu">
                    <input type="submit" class="button submit-add-to-menu right" value="Add to Menu" name="add-nav_menu-menu-item" id="submit-nav_menu" />
                    <span class="spinner"></span>
                </span>
                <?php wp_nonce_field( 'add-menu_item', 'menu-settings-column-nonce' ); ?>
            </p>
        </div>
        
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            var navMenusDiv = $('#nav_menu');
            
            if (!navMenusDiv.find('.wp-tab-bar').length) {
                var tabBar = $('<div class="wp-tab-bar"><ul class="uncode-menu-list add-menu-item-tabs"></ul></div>');
                tabBar.find('ul.uncode-menu-list')
                    .append('<li class="tabs"><a href="#nav-menus-most-recent"><?php esc_attr_e( 'Most Recent' ); ?></a></li>')
                    .append('<li><a href="#nav-menus-view-all"><?php esc_attr_e( 'View All' ); ?></a></li>')
                    .append('<li><a href="#nav-menus-search"><?php esc_attr_e( 'Search' ); ?></a></li>');
                
                navMenusDiv.find('#nav-menus-adder').before(tabBar);
            }
            
            navMenusDiv.on('click', '.wp-tab-bar a', function(e) {
                e.preventDefault();
                var targetPanel = $(this).attr('href');
                var wrapper = navMenusDiv.closest( '.accordion-section-content' );
                
                $(this).closest('.wp-tab-bar').find('li').removeClass('tabs');
                $(this).parent().addClass('tabs');
                
                navMenusDiv.find('.tabs-panel').hide().removeClass('tabs-panel-active');

                if ( navMenusDiv.find(targetPanel).find('li').length ) {
                    wrapper.removeClass( 'has-no-menu-item' );
                } else {
                    wrapper.addClass( 'has-no-menu-item' );
                }
                
                navMenusDiv.find(targetPanel).show().addClass('tabs-panel-active');
            });
            
            var searchTimeout;
            $('#nav-menus-search').closest('form').on('submit', function(e) {
                if ($(e.target).find('#quick-search-nav-menus').length) {
                    e.preventDefault();
                    return false;
                }
            });
            var searchTimeout;
            $('#custom-search-input').on('input', function() {
                var searchTerm = $(this).val();
                var spinner = $(this).next('.spinner');
                var searchList = $('#nav-menus-search-checklist');
                var wrapper = $(this).closest( '.accordion-section-content' );
                
                clearTimeout(searchTimeout);
                
                if (searchTerm.length < 2) {
                    searchList.empty();
                    wrapper.addClass( 'has-no-menu-item' );
                    return;
                }
                
                spinner.addClass('is-active');
                
                searchTimeout = setTimeout(function() {
                    $.ajax({
                        url: SiteParameters.admin_ajax,
                        type: 'POST',
                        data: {
                            action: 'uncode_search_nav_menus',
                            search_term: searchTerm,
                            current_menu_id: <?php echo intval($current_menu_id); ?>,
                            nonce: '<?php echo wp_create_nonce('uncode_search_nav_menus_nonce'); ?>'
                        },
                        success: function(response) {
                            spinner.removeClass('is-active');
                            
                            if (response.success && response.data) {
                                searchList.html(response.data);
                                wrapper.removeClass( 'has-no-menu-item' );
                            } else {
                                var errorMsg = response.data || '<?php esc_html_e( 'No menus found matching your search.', 'uncode-core' ); ?>';
                                searchList.html('<li><em>' + errorMsg + '</em></li>');
                                wrapper.addClass( 'has-no-menu-item' );
                            }
                        },
                        error: function(xhr, status, error) {
                            spinner.removeClass('is-active');
                            searchList.html('<li><em><?php esc_html_e( 'Error searching menus. Please try again.', 'uncode-core' ); ?></em></li>');
                            wrapper.addClass( 'has-no-menu-item' );
                        }
                    });
                }, 300);
            });
            
            navMenusDiv.find('.tabs-panel').hide();
            navMenusDiv.find('#nav-menus-most-recent').show();
        });
        </script>
        <style>
            .custom-search-input {
                width: 190px;
            }
        </style>
        <?php
    }

    public function uncode_ajax_add_menu_item() {
        check_ajax_referer('add-menu_item', 'menu-settings-column-nonce');

        if (!current_user_can('edit_theme_options')) {
            wp_die(-1);
        }

        require_once ABSPATH . 'wp-admin/includes/nav-menu.php';

        $menu_id = isset($_POST['menu-id']) ? intval($_POST['menu-id']) : 0;
        if (!$menu_id) {
            wp_send_json_error('Missing menu ID');
        }

        if (isset($_POST['menu-item']) && is_array($_POST['menu-item'])) {
            foreach ($_POST['menu-item'] as $key => &$menu_item_data) {
                if (isset($menu_item_data['menu-item-type']) && $menu_item_data['menu-item-type'] === 'nav_menu') {
                    $menu_item_data['menu-item-object'] = 'custom';

                    $menu_obj_id = intval($menu_item_data['menu-item-object-id']);
                    $menu = wp_get_nav_menu_object($menu_obj_id);

                    if ($menu) {
                        $menu_item_data['menu-item-title'] = $menu->name;
                        $menu_item_data['menu-item-url'] = '#menu-' . $menu->slug;
                    }

                    $menu_item_data['menu-item-db-id']      = 0;
                    $menu_item_data['menu-item-parent-id']  = 0;
                    $menu_item_data['menu-item-target']     = '';
                    $menu_item_data['menu-item-attr-title'] = '';
                    $menu_item_data['menu-item-xfn']        = '';
                    if (!isset($menu_item_data['menu-item-classes'])) {
                        $menu_item_data['menu-item-classes'] = '';
                    }
                }
            }
            unset($menu_item_data);
        }

        $item_ids = wp_save_nav_menu_items($menu_id, $_POST['menu-item']);
        if (is_wp_error($item_ids)) {
            wp_send_json_error('Error saving menu items');
        }

        $menu_items = array();
        foreach ($item_ids as $menu_item_id) {
            if ($menu_item_id && !is_wp_error($menu_item_id)) {
                $menu_items[] = wp_setup_nav_menu_item(get_post($menu_item_id));
            }
        }

        wp_send_json_success($menu_items);

        $menu_items = array();
        foreach ((array) $item_ids as $menu_item_id) {
            $menu_obj = get_post($menu_item_id);

            if (!empty($menu_obj->ID)) {
                $menu_obj        = wp_setup_nav_menu_item($menu_obj);
                $menu_obj->title = empty($menu_obj->title) ? __('Menu Item') : $menu_obj->title;
                $menu_obj->label = $menu_obj->title;
                $menu_items[]    = $menu_obj;
            }
        }

        $walker_class_name = apply_filters('wp_edit_nav_menu_walker', 'Walker_Nav_Menu_Edit', $menu_id);

        if (!empty($menu_items)) {
            $args = array(
                'after'       => '',
                'before'      => '',
                'link_after'  => '',
                'link_before' => '',
                'walker'      => new $walker_class_name(),
            );

            echo walk_nav_menu_tree($menu_items, 0, (object) $args);
        }

        wp_die();
    }
}

new Uncode_Nav_Menus_Extension();

add_filter('wp_setup_nav_menu_item', function($menu_item) {
if (!is_object($menu_item) || empty($menu_item->type)) {
		return $menu_item;
	}

	if ($menu_item->type === 'nav_menu') {
		$menu_item->type_label = __('Menu');
		$menu_item->object = 'nav_menu';

		if ($menu_item->object_id) {
			$referenced_menu = wp_get_nav_menu_object($menu_item->object_id);
			if ($referenced_menu && empty($menu_item->post_title)) {
				$menu_item->title = $referenced_menu->name;
                $menu_item->url = '#menu-' . $referenced_menu->slug;
			}
		}
	}

	return $menu_item;
});

add_filter('wp_insert_post_data', function($data, $postarr) {
	if (
        isset($data['post_type']) &&
		$data['post_type'] === 'nav_menu_item' &&
		isset($postarr['menu-item-type']) &&
		$postarr['menu-item-type'] === 'nav_menu'
    ) {
		$data['post_title'] = $postarr['menu-item-title'] ?? 'Menu';
	}
	return $data;
}, 10, 2);

