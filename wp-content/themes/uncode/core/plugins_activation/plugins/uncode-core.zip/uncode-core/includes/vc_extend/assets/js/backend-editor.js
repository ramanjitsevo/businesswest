! function($) {
	"use strict";
    window.vc.events.on('shortcodeView:ready', function(e) {
        var model = e.model,
            shortcode = typeof model !== 'undefined' ? model.attributes.shortcode : false,
            cloned =  typeof model !== 'undefined' ? model.attributes.cloned : false;
        if ( ( shortcode === 'vc_accordion_tab' ||  shortcode === 'vc_tab' ) && cloned ) {
            model.attributes.params.tab_id = model.attributes.cloned_from.params.tab_id + Math.floor(Math.random() * 10);;
        } else if ( ( shortcode === 'vc_gallery' ||  shortcode === 'uncode_index' ||  shortcode === 'uncode_slider' ) && cloned ) {
            model.attributes.params.el_id = model.attributes.cloned_from.params.el_id + Math.floor(Math.random() * 10);;
        }
    });

    window.parent.vc.events.on("vc-param-group-add-new", function(e, t, a){
		$('select', t).each(function(index) {
			var $select = $(this);
            if ( ! $select.closest('.select-wrapper').length ) {
                $select.wrap('<div class="select-wrapper" />');
            }
		});
    });

    window.parent.vc.events.on("editElementPanel:ready", function(){
        $('.vc_ui-panel-window.vc_active').addClass('is_ready');
        if (vc.active_panel && vc.active_panel.on) {
            vc.active_panel.on('hide', function() {
                $('.vc_ui-panel-window.is_ready').removeClass('is_ready');
            });
        }   
    });

}(window.jQuery);
